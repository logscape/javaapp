package com.logcape;

public interface LogscapeJMXHookMBean {

	double getCPUUtilisation();

	String dumpThreadsWithOptionalCommaDelimFilter(String filter);

}
