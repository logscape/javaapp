import javax.management.ObjectName
import javax.management.remote.JMXConnectorFactory as JmxFactory
import javax.management.remote.JMXServiceURL as JmxUrl
import javax.management.openmbean.CompositeDataSupport
import java.lang.NumberFormatException
import java.util.regex.Matcher
import java.util.regex.Pattern
//http://groovy.codehaus.org/Groovy+and+JMX


pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def stdOut = pout
def stdErr = perr

def propertyMissing(String name) {}
 
def jmxUrl(ipAddress,port){
	//println "Connecting to ipAddress:" + ipAddress+ ":" + port
	return "service:jmx:rmi://"+ ipAddress +"/jndi/rmi://"+ipAddress+":"+ port +"/jmxrmi"
}


def connect(jmxUrl){
	return JmxFactory.connect( new JmxUrl(jmxUrl))
}



def winScan(portRange){

	def cmd = [
	'bash',
	'-c',
	''' netstat -ano  '''.stripMargin() ]
	
	cmd.execute().text.split("\n").each { line ->
		elems = line.split()
		if (elems.length == 5){
			address = elems[1]
			port = address.split(":")[1]
			pid = elems[4]

		}else{
			port=-1
			pid=-1
		}
		

		try{ 
			port = port.toInteger()
			pid =  pid.toInteger()

			if  ( port > portRange[0]  && port < portRange[1] ) 
			{

				c = connect( jmxUrl("127.0.0.1",port ))
				connections[pid] = [
					"port": port
					,"connection":c.MBeanServerConnection 
					,"connector":c
				]

	

			//	pout <<   "Connected to ... " +  jmxUrl("127.0.0.1",port)  << "\n"
			}

		}catch(ClassCastException e){	
			perr <<  "Skipping ..." +  port  + "," + pid  << "\n"

		}catch(NumberFormatException e){

			// swallow this exception
		}catch(Exception e){
			errorLog ( "Tried connecting to port " + port + ", for process (pid:" + pid + ")" ) 
			errorLog ( e )  
			e.printStackTrace( pout ) 
		}
		
	}

}
	
def jmxPortScan(portRange){
	def connections = null
	println "os=" + System.properties['os.name'].toLowerCase()
	if (System.properties['os.name'].toLowerCase().contains('indows')){
		connections =winScan(portRange)
	}else{
		connections  = linuxScan(portRange)
	}
	return connections
}

def linuxScan(portRange){

	def cmd = [
	'bash',
	'-c',
	''' netstat -lap | grep java | grep 'LISTEN ' | awk '{print $4,$7}' | sed -e 's/\\[\\:\\:\\]\\://' | sort '''.stripMargin() ]


	def connections = [:] 

	cmd.execute().text.split("\n").each{ line -> 
		(port,pid) = line.split()

		try{ 
			port = port.toInteger()
			pid =  pid.split("/")[0].toInteger()

			if  ( port > portRange[0]  && port < portRange[1] ) 
			{
				c = connect( jmxUrl("127.0.0.1",port ))
				connections[pid] = [
					"port": port
					,"connection":c.MBeanServerConnection 
					,"connector":c
				]



			//	pout <<   "Connected to ... " +  jmxUrl("127.0.0.1",port)  << "\n"
			}

		}catch(ClassCastException e){	
			perr <<  "Skipping ..." +  port  + "," + pid  << "\n"

		}catch(NumberFormatException e){

			// swallow this exception
		}catch(Exception e){

			errorLog ( e )  
		}
	

	}

	return connections
}


def log( line ){
	dt = new Date()
	timestamp = String.format('%1$te-%1$tb-%1$ty %tT',dt) 
	pout <<  "" + timestamp + "\t" + line  + "\n" 
}
def logThreadInfo(beanName,line, re ){
	sep =" "
	dt = new Date()
	timestamp = String.format('%1$te-%1$tb-%1$ty %tT',dt) 
	pout << re.matcher(""+line).replaceAll(timestamp + sep  + "["+beanName+"]" + sep + '"'   )
//	pout << line.replaceAll('/^"/',timestamp + " " )
}
def errorLog( line ) 
{
	dt = new Date()
	timestamp = String.format('%1$te-%1$tb-%1$ty %tT',dt) 
	perr <<  "" + timestamp + "\t" + line  + "\n" 
}

def logAttributeValues(bean,properties,pid,port)
{


	properties.each {  name ->
		property = bean.getProperty(name) 

		if (property instanceof CompositeDataSupport)
		{
			keyValuePairs = [] 
			property.getCompositeType().keySet().each{ key -> 
				keyValuePairs.add (  key + ":" +  property.get(key)  ) 
			}

			logline =   keyValuePairs.join("\t")
	
		}else{
			logline =  bean.getProperty( name ) 		
		}
		log("" +  "[" + bean.name() + "]"  +  "." + name + ":\t" + logline +  "\t" + "pid:" + pid + "port:"  + port) 


	}
}

def execute( jmxConnections, jmxQuery)
{
	if (!jmxQuery.contains("@")) {
		throw new Exception("No attribute list specified for java query" );
	}

	// dequeue the list 
	jmxQueryElems = jmxQuery.split("@").reverse() as List
	beanName = jmxQueryElems.pop() 
	beanPropertyList = jmxQueryElems.reverse() 

	jmxConnections.each { pid,v -> 
		conn = v["connection"]
		port = v["port"]
		try{
			conn.queryNames(new ObjectName(beanName),null).each{ beanName -> 
				bean = new GroovyMBean(conn,beanName)
				logAttributeValues(bean,beanPropertyList,pid,port)
			}

		}catch(javax.management.InstanceNotFoundException e) {
			perr << "Could not find ["+ jmxQuery +"]. Failed on port="+ v["port"] +",pid="+v["pid"]+" "  << "\n"
		}
	}	
}

def ranges(jmxPortList){
	
	range = [] 

	jmxPortList.split(",").each{ elem  -> 
		range.add (  elem.split("-").collect { it -> it.toInteger()  }  ) 

	}
	return range 
}
def arguments(defaults){
	def parameters = defaults
	args.each{ argument -> 
		if ( argument.contains("=") )
		{
			(key,value)= argument.split("=")
			parameters[key] = value.replaceAll('"','') 
		}
	}
	return parameters 
}

parameters = arguments( ["jmxPortRanges":"9000-9999", "threadFilter":"RUNNABLE,BLOCKABLE"] ) 

jmxPortRanges = jmxPortRanges == null ? parameters["jmxPortRanges"]  : jmxPortRanges

threadFilter = threadFilter == null ? parameters["threadFilter"] : threadFilter


def portRanges = ranges( jmxPortRanges ) // [8900,9100]
def jmxConnections = []
def regexCompiled= Pattern.compile('^"', Pattern.MULTILINE)

portRanges.each { portRange -> 
	
	jmxConnections = jmxPortScan(portRange) 
	jmxConnections.each { pid,jmxInfo  ->
		server = jmxInfo["connection"]
		port = jmxInfo["port"]

		
		objName="com.liquidlabs.vso:AGENT=*"
		server.queryNames( new ObjectName(objName), null).each { objectName -> 
		//bean  = new GroovyMBean(jmxInfo["connection"],"com.liquidlabs.vso:AGENT=*@dumpThreadsWithOptionalCommaDelimFilter")	
			bean  = new GroovyMBean(jmxInfo["connection"],objectName)	
			threadInfo = bean.invokeMethod("dumpThreadsWithOptionalCommaDelimFilter" ,threadFilter)
			logThreadInfo("" + bean.name() + ":" + port ,threadInfo,regexCompiled)
		}
	}
	
	jmxConnections.each { k,v -> 
		c = v["connector"] 
		c.close()
	} 
}

return