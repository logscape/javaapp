import org.codehaus.groovy.runtime.StackTraceUtils

import javax.management.ObjectName
import javax.management.remote.JMXConnectorFactory as JmxConnectorFactory
import javax.management.remote.JMXServiceURL as JmxServiceUrl
import javax.management.remote.JMXConnector
import javax.management.openmbean.CompositeDataSupport
import java.lang.NumberFormatException
//http://groovy.codehaus.org/Groovy+and+JMX
/*def bundleId = null
for(def arg:args){
	if (arg.contains("bundleId")){
		bundleId=arg.split("=")[1] 
	}
}*/
pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def stdOut = pout
def stdErr = perr

def propertyMissing(String name) {}


def scriptName = "settings.groovy"
def pathToLib "./lib/"+scriptName 
//def pathToLib = bundleId == null ? "lib/"+scriptName : bundleId+"/lib/"+scriptName
println pathToLib
def parent = getClass().getClassLoader()
def loader = new GroovyClassLoader(parent)
def Settings = loader.parseClass(new File(pathToLib))

def JBossServiceUrl(ipAddress,port){
	ipAddress="LCYLS00008.sbetenv.ads"
	port="9999"
	return "service:jmx:remoting-jmx://"+ipAddress+":" + "9999"
}

def log( line ){
	dt = new Date()
	timestamp = String.format('%1$te-%1$tb-%1$ty %tT',dt) 
	pout <<  "" + timestamp + "\t" + line  + "\n" 
}

def errorLog( line ) { 
	dt = new Date()
	timestamp = String.format('%1$te-%1$tb-%1$ty %tT',dt) 
	perr <<  "" + timestamp + "\t" + line  + "\n" 
}

def settings =  Settings.newInstance()
def arguments  =  args  as List 
settings.init(_bindings) 
def queryString=settings.global["query"]
log(settings.global)
log(settings.config)
message="<" +  settings.global + "\n" + settings.config + "\n" + ">" 
if (queryString==null){
	throw new Exception("Required parameter ['query'] does not exist" + "\n" +  message)
}

