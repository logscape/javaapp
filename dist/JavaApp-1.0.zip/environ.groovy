import org.codehaus.groovy.runtime.StackTraceUtils

import javax.management.ObjectName
import javax.management.remote.JMXConnectorFactory as JmxConnectorFactory
import javax.management.remote.JMXServiceURL as JmxServiceUrl
import javax.management.remote.JMXConnector
import javax.management.openmbean.CompositeDataSupport
import java.lang.NumberFormatException
import groovy.json.JsonBuilder
//http://groovy.codehaus.org/Groovy+and+JMX
/*def bundleId = null
for(def arg:args){
	if (arg.contains("bundleId")){
		bundleId=arg.split("=")[1] 
	}
}*/
pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def stdOut = pout
def stdErr = perr
Logger logger = new Logger()
logger.setOutStream(pout)
logger.setErrStream(perr)

def propertyMissing(String name) {}


def scriptName = "settings.groovy"
def pathToLib = cwd == null ? "lib/"+scriptName : cwd + "/deployed-bundles/"+bundleId+"/lib/"+scriptName
def parent = getClass().getClassLoader()
def loader = new GroovyClassLoader(parent)
def Settings = loader.parseClass(new File(pathToLib))

def JBossServiceUrl(ipAddress,port){
	ipAddress="LCYLS00008.sbetenv.ads"
	port="9999"
	return "service:jmx:remoting-jmx://"+ipAddress+":" + "9999"
}


def linuxScan(portRange,serviceUrl,jmxAuth){


	def cmd = [
	'bash',
	'-c',
	''' netstat -lap | grep java | grep 'LISTEN ' | awk '{print $4,$7}' | sed -e 's/\\[\\:\\:\\]\\://' | sort '''.stripMargin() ]


	def connections = [:] 
	
	counter = 0 
	cmd.execute().text.split("\n").each{ line -> 
		(port,pid) = line.split()
		if (port.contains(":") ) { port = port.split(":")[1] }
		try{ 
			port = port.toInteger()
			pid =  pid.split("/")[0].toInteger()
			cred=getAuth ( jmxAuth, counter ) 
			if  ( port > portRange[0]  && port < portRange[1] ) 
			{
				//c = connector( jmxUrl("127.0.0.1",port ))
				c = connect( serviceUrl("127.0.0.1",port ), cred)
				connections[pid] = [
					"port": port
					,"connection":c.MBeanServerConnection 
					,"connector":c
				]



			//	pout <<   "Connected to ... " +  jmxUrl("127.0.0.1",port)  << "\n"
			}

		}catch(ClassCastException e){	
			perr <<  "Skipping ..." +  port  + "," + pid  << "\n"

		}catch(NumberFormatException e){

			// swallow this exception
		}catch(Exception e){

			errorLog ( e )  
			e.printStackTrace(pout)
		}
	

	}

	return connections
}

class Logger{
	private static verbose=false;
	private static Logger instance = null;
	private static pout;
	private static perr;
	private Logger(){}

	def setVerboseTrue(){
		verbose=true;
	}
	
	def getInstance(){
		if(instance==null){
			instance = new Logger();
		}
		return instance;
	}
	def setOutStream(def out){
		pout=out		
	}
	def setErrStream(def err){
		perr=err
	} 
	def log( line ){
		def dt = new Date()
		def timestamp = String.format('%1$te-%1$tb-%1$ty %tT',dt) 
		pout <<  "" + timestamp + "\t" + line  + "\n" 
	}

	def error( line ) { 
		def dt = new Date()
		def timestamp = String.format('%1$te-%1$tb-%1$ty %tT',dt) 
		perr <<  "" + timestamp + "\t" + line  + "\n" 
	}

	def verbose(line){
		if(verbose){
			error(line);
		}
	}
}

def getAuth(auth,index) {
	if (auth == null) { return null } 
	
	elems = auth.split(",")
	if (index > elems.size()  - 1 ) { return null } 
	
	cred = elems[index] 
	if (cred.contains(":")) {
		credArgs =cred.split(":")
		
		return [ (JMXConnector.CREDENTIALS):credArgs ]  	
	}

	return null
}


class Port{
	def port
	def Port(p){
		port =  p
	}

	def isValid(portIntValue){
		if (isRange()){
			def (portBegin,portEnd) = rangeValues() 
			return (  (portIntValue > portBegin) && (portIntValue < portEnd) ) 
		}else if (isInteger()){
			return (intValue() == portIntValue) 
		}
		return false
	}

	def isInteger() {return (port.contains("-") == true) ? false : port.isInteger()  }

	def isRange() {
		if (port.contains("-")) {
			def (v1,v2)=port.split("-");
			return  ( v1.isInteger() &&  v2.isInteger() )
		}
		return false
	}
	def intValue() {
		return port.toInteger()
	} 

	def rangeValues() {
		def (v1,v2) = port.split("-") as List
		def portBegin = v1.toInteger()
		def portEnd = v2.toInteger()
		if (portEnd < portBegin ) {
			throw new Exception("Invalid port-range: " + port ) 
		}
		return[portBegin,portEnd]
	}

	def contains(p) {
		def (portBegin,portEnd) =  rangeValues() 
		if ((p > portBegin) && (p < portEnd )){
			return true
		}

		return false 
	}
}
class JmxUrlBuilder { 
	def scanner
	def ns  
	def JmxUrlBuilder(scanner){
		this.scanner = scanner 
	}

	def generateUrls( urlConfig) {
		def urls = [] 
		def hosts = urlConfig.hosts.split(",")  as List
		def rmiName =(urlConfig.rmi==null)? "jmxrmi" : urlConfig.rmi.name
		def jndiPort=""
		def jndiHost=""
		def jndiUrl=null
		if (urlConfig.jndi !=null){
			jndiPort= (urlConfig.jndi.port==null)? "" : ":"+urlConfig.jndi.port
			jndiHost= (urlConfig.jndi.host==null)? "" : urlConfig.jndi.host
		}
		jndiUrl = (urlConfig.jndi == null) ? "/jndi" : jndiHost + jndiPort+"/jndi"  
		for (host in hosts) {
			def port = (urlConfig.port != null) ? ":" + urlConfig.port   : "" 
			def address = host + port 
			def rmiPart = "rmi://"+address + "/"+rmiName
			def jmxUrl =  "service:jmx:rmi://" + jndiUrl + "/"  +   rmiPart  
			urls.add(jmxUrl) 
		}
		return urls
	}

	def generate() {return generate(this.ns)}

	def generate(ns){
		def ports = ns.ports.split(",") as List  
		def hosts  =  (ns.hosts != null) ?  ns.hosts :  "127.0.0.1"	
		def jmxUrls =  []
		def jmxPorts = [] 
		for (def port:ports){
			def p = new Port(port) 
			if (ns.hosts != null) { jmxPorts.add(p.intValue()) ; continue } 
			if (scanner.contains(p)){
				jmxPorts.addAll( scanner.get(p)) 
			} 
		}
		for (port in jmxPorts){
			def urls =   generateUrls([
						"hosts":hosts
						,"port":port 
						,"jndi":ns.jndi
						,"rmi":ns.rmi

			])
			jmxUrls.addAll(urls)  
		}	
		return jmxUrls  
	}


}
class PortScanner {
	def info = [:]
	def ports = []
	def scannedPorts = [] 
	def add(p){
		ports.add(p) 
	} 

	def isValidPort(port) {
		for(def p:ports){
			if (p.isValid(port)) { return true } 
			 
		}
		return false
	}
	def contains(p){
		
		if (p.isInteger()){
			return scannedPorts.contains(p.intValue())
		}
		if(p.isRange()){
			def (portBegin,portEnd)=p.rangeValues()
			for(def port:scannedPorts){
				if ((port.intValue() >= portBegin) && (port.intValue()  <= portEnd) ){
					return true
				}
			}
		}
		return false

	}
	def get(p){
		def orderedPortList = [] 
		if (p.isInteger()){
			orderedPortList = scannedPorts.contains(p.intValue()) ? [p.intValue()] : null 
		}
		if(p.isRange()){
			def (portBegin,portEnd)=p.rangeValues()
			for(def port:scannedPorts){
				if ((port >= portBegin) && (port  <= portEnd) ){
					orderedPortList.add(port)
				}
			}
		}
		return orderedPortList

	}

	def scan() {

		def getWinPorts = {  
			def ports = [] 
			def cmd = "netstat -ano" 
			def cmdOut = cmd.execute().text 
			def lines = cmdOut.split("\r\n") 
			for (def line: lines){
				if(line.contains("TCP") != true ) { continue }
				def tokens = line.split() as List 
				def port = tokens[1].split(":")[1]
				def pid = -1 
				if (tokens[4].isInteger()){
					pid = tokens[4].toInteger() 
				}
				if (port.isInteger() == false) { continue } 
				if (isValidPort(port.toInteger())){ 
					scannedPorts.add(port.toInteger())
					info[port] = [:]
					info[port]["pid"] = pid 
					

				}

			} 
			scannedPorts.sort() 
			return scannedPorts 
		}
		return getWinPorts() 
	}
}


class Service{
	def settings
	def jmxUrls = [] 
	def context = [:]
	def scanner
	def connections=[] 
	def queryResults=[]
	def logger 
	def Service(settings){
		this.settings = settings;
		this.scanner = new PortScanner(); 
		this.logger=new Logger();
	}
	def connectAll(jmxUrls){
		connections = []
		for(def jmxUrl:jmxUrls){
			try{
				connections.add(JmxConnectorFactory.connect( new JmxServiceUrl(jmxUrl),null))
			}catch(Exception e){
				this.logger.error("Could not connect to ["+jmxUrl+"]\n Exception: "+e) 
			}
		}
		return connections
	}
	def initVerboseLogging(){
		if (settings.global.keySet().contains("verbose")){
			def verbose=settings.global["verbose"].asBoolean();
			if(verbose){
				this.logger.setVerboseTrue();
			}
		}
	}
	
	def init(){
		initVerboseLogging();

		def keys = settings.config.keySet()
		for (def ns:keys){
			if (settings.isReserved(ns)){
				continue;
			}
			def ports = settings.config[ns].ports 	
			if(ports==null){
				this.logger.error("No [ports] defined for["+ns+"]");
				this.logger.verbose(settings.global);
				this.logger.verbose(settings.config);
			}

			ports.split(",").each { p -> scanner.add(new Port(p)) } 
		}
		scanner.scan() 
		def urlBuilder = new JmxUrlBuilder(scanner)
		for (def ns:keys){
			if(settings.isReserved(ns)){
				continue
			}
			def nsSettings  = settings.config[ns]
			settings.config[ns].jmxurls =  urlBuilder.generate(nsSettings)
			jmxUrls.addAll(settings.config[ns].jmxurls) 
			settings.config[ns].jmxconnections =  connectAll(settings.config[ns].jmxurls)
			connections.addAll( settings.config[ns].jmxconnections ) 
		}
	}
	def collectData(q){ return startOn(q) }

	def startOn(queryString){
		def keys = settings.config.keySet()
		def nsResults = [] 
		for(def ns:keys){
			def rs =  execute(settings.config[ns].jmxconnections , queryString )   
			queryResults.addAll(rs) 
			settings.config[ns].results = rs 
			nsResults.add(settings.config[ns]) 
		}
		return settings.config 
	} 

	def shutdown() {
	} 

	def execute(connections,queryString){
		def rs=[]
		def queryTokens = queryString.split("@") as List
		def mBeanName = queryTokens[0]
		queryTokens.remove(0)
		for(def c:connections){
			def bean 
			try{
				bean =  new GroovyMBean(c.MBeanServerConnection,mBeanName)		
			}catch(javax.management.InstanceNotFoundException f){
				this.logger.error("Invalid instance["+mBeanName+"] on [" + c +"]" );
				continue
			}catch(Exception e){
				this.logger.error("Could not connect to MBean["+mBeanName+"]  using["+c+"]")
				this.logger.error(e) 
				continue
			}
			def rsRow = []
			def str="" +  c  
			def host=str.split("rmi://")[2].split("/")[0]  
			for (def property: queryTokens){
				def beanProperty
				try{
					beanProperty=bean.getProperty(property)
				}catch(javax.management.AttributeNotFoundException e){
					this.logger.error("Invalid property [" + property + "] on "+ mBeanName)
					continue 	
				}
				def data = ["name: \"" + property+ "\""]  
				if (beanProperty instanceof CompositeDataSupport){
					def propertyData = [] 
					beanProperty.getCompositeType().keySet().each { propertyData.add(it + ": \"" + beanProperty.get(it)  +"\"") } 				
					data.addAll(propertyData)	
					rsRow.add(data)
				}else{
					data.addAll([ property + ": \"" + beanProperty+"\""])
					rsRow.add(data)
				}
				data.addAll(["host: \""+host+"\""])
			}	 
			rs.add(rsRow)
		}
		return rs 
	}

}

def dataLog(data) {
	def logger = new Logger() 
	def getMetaData = { ns -> 
		label  =  (ns.label == null) ?  "" : "label"+ ": \"" + ns.label +"\""
		return label
	}
	def keys=data.keySet()
	for(def ns: keys){
		meta = getMetaData(data[ns]) 
		if (data[ns].keySet().contains("results") == false) { continue; } 
		for(def result: data[ns].results){
			tokens = []    
			result.each { row ->  logger.log(row.join(", ") + "," + meta  ) } 
		}
	
	}	
}

def settings =  Settings.newInstance()
def arguments  =  args  as List 

def message="{"
for(def key:_bindings){
	message=message+", "+key+": \""+_bindings[key]+"\""
}
message=message+"}"
logger.log(message);

