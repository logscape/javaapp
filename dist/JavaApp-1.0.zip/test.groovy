
def path="HeapMemoryUsage" 
def elems= path.split("\\.")
print elems[0..elems.size()-2].join(".")


